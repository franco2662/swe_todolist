
angular.module('todoService', [])


    .factory('Todos', function($http) {
        return {
            get : function() {
                return $http.get('/v1/todos');
            },
            create : function(todoData) {
                return $http.post('/v1/todos', todoData);
            },
            delete : function(id) {
                return $http.delete('/v1/todos/' + id);
            }
        }
    });
