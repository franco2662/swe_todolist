

angular.module('bogoTodo', ['todoController', 'todoService']);
