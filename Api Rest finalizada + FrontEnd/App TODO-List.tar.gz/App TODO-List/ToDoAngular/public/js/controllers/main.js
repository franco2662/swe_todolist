
    
angular.module('todoController', [])

    .controller('mainController', function($scope, $http) {
        $scope.formData = {};


        $http.get('/v1/todos')
                .success(function(data) {
                        $scope.todos = data;
                })
                .error(function(data) {
                        console.log('Error: ' + data);
                });


        $scope.createTodo = function() {
                $http.post('/v1/todos', $scope.formData)
                        .success(function(data) {
                                $scope.formData = {}; 
                                $scope.todos = data;
                        })
                        .error(function(data) {
                                console.log('Error: ' + data);
                        });
        };


        $scope.deleteTodo = function(id) {
                $http.delete('/v1/todos/' + id)
                        .success(function(data) {
                                $scope.todos = data;
                        })
                        .error(function(data) {
                                console.log('Error: ' + data);
                        });
        };

    });
