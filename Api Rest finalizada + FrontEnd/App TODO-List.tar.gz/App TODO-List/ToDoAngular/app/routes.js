
var Todo = require('./models/todo');

//colocar las rutas de nuestra aplicacion a module.exports
module.exports = function(app) {

//funcion que muestra todas las notas
    app.get('/v1/todos', function(req, res) {

//Encuentra los todos en la base de datos  
      Todo.find(function(err, todos) {

            // si existe un error envia el tipo de error
            if (err)
                res.send(err)

            res.json(todos); // sino, envia todas las notas
        });
    });


   //funcion que se encarga de crear una nueva nota y luego mostrarlas todas, ya actualizadas
    app.post('/v1/todos', function(req, res) {

        // crea una nota y recopila la informacion de ella 
        Todo.create({
            text : req.body.text,
            done : false
        }, function(err, todo) {
            if (err)
                res.send(err);

            // en esta linea, obtiene y devuelve todas las notas despues de crear una 
            Todo.find(function(err, todos) {
                if (err)
                    res.send(err)
                res.json(todos);
            });
        });

    });

    //funcion que se encarga de borrar una nota a traves de un id
    app.delete('/v1/todos/:todo_id', function(req, res) {
        Todo.remove({
            _id : req.params.todo_id
        }, function(err, todo) {
            if (err)
                res.send(err);

     	//funcion que devuelte todas las notas despues de borrar una
            Todo.find(function(err, todos) {
                if (err)
                    res.send(err)
                res.json(todos);
            });
        });
    });
};
